/*
 * The contents of this file are subject to the terms 
 * of the Common Development and Distribution License 
 * (the "License").  You may not use this file except 
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt or 
 * https://glassfish.dev.java.net/public/CDDLv1.0.html. 
 * See the License for the specific language governing 
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL 
 * HEADER in each file and include the License file at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt.  If applicable, 
 * add the following below this CDDL HEADER, with the 
 * fields enclosed by brackets "[]" replaced with your 
 * own identifying information: Portions Copyright [yyyy] 
 * [name of copyright owner]
 */
// Copyright (c) 1998, 2005, Oracle. All rights reserved.  
package oracle.toplink.essentials.internal.ejb.cmp3.transaction;

import javax.persistence.EntityTransaction;
import javax.persistence.TransactionRequiredException;
import oracle.toplink.essentials.internal.ejb.cmp3.EntityManagerImpl;
import oracle.toplink.essentials.exceptions.TransactionException;

/**
 * INTERNAL:
 * JDK 1.5 specific version of JTATransactionWrapper. Differs from the JDK 1.4 version
 * in that it implements a different version of the TransactionWrapper interface, 
 * uses a different EntityManager, and returns a different EntityTransaction version.
 * 
 * @see oracle.toplink.essentials.internal.ejb.cmp3.transactionJTATransactionWrapper
 */
public class JTATransactionWrapper 
    extends oracle.toplink.essentials.internal.ejb.cmp3.transaction.base.JTATransactionWrapper 
    implements TransactionWrapper
{

    public JTATransactionWrapper(EntityManagerImpl entityManager) {
        super(entityManager);
    }
    
  /**
   *  An ENtityTransaction cannot be used at the same time as a JTA transaction
   *  throw an exception
   */
    public EntityTransaction getTransaction(){
        throw new IllegalStateException(TransactionException.entityTransactionWithJTANotAllowed().getMessage());
    }

    protected void throwCheckTransactionFailedException() {
        throw new TransactionRequiredException(TransactionException.externalTransactionNotActive().getMessage());
    }
}

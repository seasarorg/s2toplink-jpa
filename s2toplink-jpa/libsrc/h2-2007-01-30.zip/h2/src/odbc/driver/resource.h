/*
 * Copyright 2004-2006 H2 Group. Licensed under the H2 License, Version 1.0 (http://h2database.com/html/license.html).
 */
 
#define IDD_CONFIG                      101
#define IDI_ICON                        102
#define IDC_URL                         1000
#define IDC_NAME                        1001
#define IDC_USER                        1002
#define IDC_PASSWORD                    1003

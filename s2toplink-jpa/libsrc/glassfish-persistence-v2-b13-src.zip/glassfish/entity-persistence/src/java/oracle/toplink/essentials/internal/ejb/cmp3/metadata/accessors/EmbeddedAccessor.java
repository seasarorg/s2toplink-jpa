/*
 * The contents of this file are subject to the terms 
 * of the Common Development and Distribution License 
 * (the "License").  You may not use this file except 
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt or 
 * https://glassfish.dev.java.net/public/CDDLv1.0.html. 
 * See the License for the specific language governing 
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL 
 * HEADER in each file and include the License file at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt.  If applicable, 
 * add the following below this CDDL HEADER, with the 
 * fields enclosed by brackets "[]" replaced with your 
 * own identifying information: Portions Copyright [yyyy] 
 * [name of copyright owner]
 */
// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.essentials.internal.ejb.cmp3.metadata.accessors;

import javax.persistence.AssociationOverride;
import javax.persistence.AssociationOverrides;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.JoinColumn;

import oracle.toplink.essentials.internal.ejb.cmp3.metadata.accessors.ClassAccessor;
import oracle.toplink.essentials.internal.ejb.cmp3.metadata.accessors.objects.MetadataAccessibleObject;

import oracle.toplink.essentials.internal.ejb.cmp3.metadata.columns.MetadataColumn;

import oracle.toplink.essentials.internal.ejb.cmp3.metadata.MetadataDescriptor;

import oracle.toplink.essentials.internal.helper.DatabaseField;

import oracle.toplink.essentials.mappings.AggregateObjectMapping;
import oracle.toplink.essentials.mappings.DatabaseMapping;
import oracle.toplink.essentials.mappings.OneToOneMapping;

/**
 * An embedded relationship accessor.
 * 
 * @author Guy Pelletier
 * @since TopLink EJB 3.0 Reference Implementation
 */
public class EmbeddedAccessor extends BasicAccessor {
    protected boolean m_isEmbeddedId;
    
    /**
     * INTERNAL:
     */
    public EmbeddedAccessor(MetadataAccessibleObject accessibleObject, ClassAccessor classAccessor, boolean isEmbeddedId) {
        super(accessibleObject, classAccessor);
        
        m_isEmbeddedId = isEmbeddedId;
    }
    
    /**
     * INTERNAL:
     */
	public boolean isEmbedded() {
        return true;
    }
    
    /**
     * INTERNAL:
     */
	public boolean isEmbeddedId() {
        return m_isEmbeddedId;
    }
    
    /**
     * INTERNAL:
     * Process an @Embedded or embedded element. Also called when processing 
     * an @EmbeddedId or embedded-id element.
     */    
    public void process() {
        // If we are an embedded id, process the embedded is metadata.
        if (isEmbeddedId()) {
            processEmbeddedId();    
        }
        
        // Tell the Embeddable class to process itself
        MetadataDescriptor referenceDescriptor = processEmbeddableClass();
        
        // Store this descriptor metadata. It may be needed again later on to
        // look up a mappedBy attribute.
        m_descriptor.addAggregateDescriptor(referenceDescriptor);
        
        if (m_descriptor.hasMappingForAttributeName(getAttributeName())) {
            // XML/Annotation merging. XML wins, ignore annotations.
            m_logger.logWarningMessage(m_logger.IGNORE_MAPPING, m_descriptor, this);
        } else {
            // Create an aggregate mapping and do the rest of the work.
            AggregateObjectMapping mapping = new AggregateObjectMapping();
            mapping.setIsReadOnly(false);
            mapping.setIsNullAllowed(true);
            mapping.setReferenceClassName(getReferenceClassName());
            mapping.setAttributeName(getAttributeName());    
        
            // Will check for PROPERTY access
            setAccessorMethods(mapping);
        
            // Process attribute overrides.
            processAttributeOverrides(mapping);
            
            // Process association overrides.
            processAssociationOverrides(mapping);
        
            // Add the mapping to the descriptor and we are done.
            m_descriptor.addMapping(mapping);
        }
    }
    
    /**
     * INTERNAL:
     * Process an @AssociationOverride for an embedded object, that is, an 
     * aggregate object mapping in TopLink. 
     * 
     * This functionality is not supported in XML, hence why this method is 
     * defined here instead of on MetadataProcessor.
     * 
     * Also this functionality is currently optional in the EJB 3.0 spec, but
     * since TopLink can handle it, it is implemented and assumes the user has
     * properly configured its use since it will fail silently.
	 */
	protected void processAssociationOverride(AssociationOverride associationOverride, AggregateObjectMapping aggregateMapping) {
        MetadataDescriptor aggregateDescriptor = getReferenceDescriptor();
        
        // AssociationOverride.name(), the name of the attribute we want to
        // override.
        String name = associationOverride.name();
        DatabaseMapping mapping = aggregateDescriptor.getMappingForAttributeName(name);
        
        if (mapping == null) {
            // WIP - For now fail silently.
            //throw ValidationException.invalidEmbeddableAttribute(aggregateDescriptor.getJavaClass(), name, descriptor.getJavaClass(), aggregateMapping.getAttributeName());
        }
        
        if (mapping.isOneToOneMapping()) {
            int index = 0;
            
            for (JoinColumn joinColumn : associationOverride.joinColumns()) {
                // We can't change the mapping from the aggregate descriptor
                // so we have to add field name translations. This needs to be
                // tested since I am not entirely sure if this will acutally
                // work.
                // In composite primary key case, how do we association the
                // foreign keys? Right now we assume the association overrides
                // are specified in the same order as the original joinColumns,
                // therefore in the same order the foreign keys were added to
                // the mapping.
                DatabaseField fkField = (DatabaseField) ((OneToOneMapping) mapping).getForeignKeyFields().elementAt(index++);
                aggregateMapping.addFieldNameTranslation(joinColumn.name(), fkField.getName());
            }   
        } else {
            // WIP - For now fail silently.
        }
	}
    
    /**
     * INTERNAL:
     * Process an @AssociationOverrides for an embedded object, that is, an
     * aggregate object mapping in TopLink. 
     * 
     * It will also look for an @AssociationOverride.
     */
    protected void processAssociationOverrides(AggregateObjectMapping mapping) {
        // Look for an @AssociationOverrides.
        AssociationOverrides associationOverrides = getAnnotation(AssociationOverrides.class);
        if (associationOverrides != null) {
            for (AssociationOverride associationOverride : associationOverrides.value()) {
                processAssociationOverride(associationOverride, mapping);
            }
        }
        
        // Look for an @AssociationOverride.
        AssociationOverride associationOverride = getAnnotation(AssociationOverride.class);	
        if (associationOverride != null) {
            processAssociationOverride(associationOverride, mapping);
        }
    }
    
    /**
     * INTERNAL:
     * Process an @AttributeOverride or attribute-override element for an 
     * embedded object, that is, an aggregate object mapping in TopLink.
	 */
	protected void processAttributeOverride(AggregateObjectMapping mapping, MetadataColumn column) {
        String attributeName = column.getAttributeName();
        
        // Set the attribute name on the aggregate.
        DatabaseMapping aggregateMapping = getReferenceDescriptor().getMappingForAttributeName(attributeName);
        
        if (aggregateMapping == null) {
            m_validator.throwInvalidEmbeddableAttribute(getJavaClass(), mapping.getAttributeName(), getReferenceDescriptor().getJavaClass(), attributeName);
        }
        
        // A sub-class to a mapped superclass may override an embedded attribute override.
        DatabaseField field;
        if (m_descriptor.hasAttributeOverrideFor(attributeName)) {
            field = m_descriptor.getAttributeOverrideFor(attributeName).getDatabaseField();
        } else {
            field = column.getDatabaseField();
        }
        
        mapping.addFieldNameTranslation(field.getQualifiedName(), aggregateMapping.getField().getName());
	}
    
    /**
     * INTERNAL: (Overridden in XMLEmbeddedAccessor)
     * Process an @AttributeOverrides for an embedded object, that is, an
     * aggregate object mapping in TopLink. 
     * 
     * It will also look for an @AttributeOverride.
     */
    protected void processAttributeOverrides(AggregateObjectMapping mapping) {
        // Look for an @AttributeOverrides.
        AttributeOverrides attributeOverrides = getAnnotation(AttributeOverrides.class);
        
        if (attributeOverrides != null) {
            for (AttributeOverride attributeOverride : attributeOverrides.value()) {
                processAttributeOverride(mapping, new MetadataColumn(attributeOverride.column(), attributeOverride.name(), getAnnotatedElement()));
            }
        }
        
        // Look for an @AttributeOverride.
        AttributeOverride attributeOverride = getAnnotation(AttributeOverride.class);	
        if (attributeOverride != null) {
            processAttributeOverride(mapping, new MetadataColumn(attributeOverride.column(), attributeOverride.name(), getAnnotatedElement()));
        }
    }
    
    /**
     * INTERNAL:
     * Process an embeddable class. If processing for an @EmbeddedId or 
     * embedded-id element, we must add the primary key field names to our 
     * processing entity.
     */
    protected MetadataDescriptor processEmbeddableClass() {
        MetadataDescriptor embeddableDescriptor = m_project.getDescriptor(getReferenceClass());
        ClassAccessor embeddableAccessor = embeddableDescriptor.getClassAccessor();
        
        if (embeddableAccessor == null) {
            embeddableAccessor = processAccessor(embeddableDescriptor);
        }
        
        // We need to set the primary keys on the owning descriptor metadata if 
        // this is an @EmbeddedId or embedded-id.
        if (isEmbeddedId() && ! m_descriptor.ignoreIDs()) {
            for (DatabaseMapping mapping : embeddableDescriptor.getMappings()) {
                DatabaseField field = (DatabaseField) mapping.getField().clone();
                field.setTableName(m_descriptor.getPrimaryTableName());
                m_descriptor.addPrimaryKeyField(field);
            }
        }
        
        return embeddableDescriptor;
    }
    
    /**
     * INTERNAL:
     * Process an EmbeddedId or embedded-id element. After processing the 
     * Embeddable class we must add the primary key field names to our 
     * processing entity.
     */
    public void processEmbeddedId() {
        if (m_descriptor.ignoreIDs()) {
            // XML/Annotation merging. XML wins, ignore annotations.
            m_logger.logWarningMessage(m_logger.IGNORE_EMBEDDED_ID, this);
        } else {
            // Check if we already processed an EmbeddedId for this entity.
            if (m_descriptor.hasEmbeddedIdAttribute()) {
                m_validator.throwMultipleEmbeddedIdsFound(getJavaClass(), getAttributeName(), m_descriptor.getEmbeddedIdAttributeName());
            } 
            
            // Check if we already processed an Id or IdClass.
            if (m_descriptor.hasPrimaryKeyFields()) {
                m_validator.throwEmbeddedIdAndIdFound(getJavaClass(), getAttributeName(), m_descriptor.getIdAttributeName());
            }
            
            // Set the PK class.
            m_descriptor.setPKClass(getReferenceClass());
            
            // Store the embeddedId attribute name.
            m_descriptor.setEmbeddedIdAttributeName(getAttributeName());
        }
    }
}

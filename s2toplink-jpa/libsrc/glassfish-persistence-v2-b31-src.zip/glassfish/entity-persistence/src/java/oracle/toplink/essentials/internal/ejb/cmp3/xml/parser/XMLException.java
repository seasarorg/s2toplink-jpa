package oracle.toplink.essentials.internal.ejb.cmp3.xml.parser;

import java.util.ArrayList;
import java.util.List;

import oracle.toplink.essentials.internal.helper.Helper;

public class XMLException extends RuntimeException {
    private List m_nestedExceptions;

    public XMLException() {
        super();
        m_nestedExceptions = new ArrayList(); 
    }
    
    public void addNestedException(Exception nestedException) {
        m_nestedExceptions.add(nestedException);
    }
    
    public String getMessage() {
        StringBuffer buffer = new StringBuffer();
        Exception nestedException;
        for (int x=0; x<m_nestedExceptions.size(); x++) {
            nestedException = (Exception) m_nestedExceptions.get(x);
            buffer.append(Helper.cr());
            buffer.append('(');
            buffer.append(x + 1);
            buffer.append(". ");
            buffer.append(nestedException.getMessage());
            buffer.append(')');
        }
        return buffer.toString();
    }
    
    public String toString() { return getMessage(); }
}

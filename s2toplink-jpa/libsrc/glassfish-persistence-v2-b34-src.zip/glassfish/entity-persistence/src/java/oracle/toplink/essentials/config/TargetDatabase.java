/*
 * The contents of this file are subject to the terms 
 * of the Common Development and Distribution License 
 * (the "License").  You may not use this file except 
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt or 
 * https://glassfish.dev.java.net/public/CDDLv1.0.html. 
 * See the License for the specific language governing 
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL 
 * HEADER in each file and include the License file at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt.  If applicable, 
 * add the following below this CDDL HEADER, with the 
 * fields enclosed by brackets "[]" replaced with your 
 * own identifying information: Portions Copyright [yyyy] 
 * [name of copyright owner]
 */
// Copyright (c) 1998, 2007, Oracle. All rights reserved.  
package oracle.toplink.essentials.config;

/**
 * Logging level persistence property values.
 * 
 * 
 * JPA persistence property Usage:
 * 
 * properties.add(TopLinkProperties.TargetDatabase, TargetDatabase.Oracle);
 * 
 * Property values are case-insensitive
 */
public class TargetDatabase {
    public static final String  Auto = "Auto";
    public static final String  Oracle = "Oracle";
    public static final String  Attunity = "Attunity";
    public static final String  Cloudscape = "Cloudscape";
    public static final String  Database = "Database";
    public static final String  DB2 = "DB2";
    public static final String  DB2Mainframe = "DB2Mainframe";
    public static final String  DBase = "DBase";
    public static final String  Derby = "Derby";
    public static final String  HSQL = "HSQL";
    public static final String  Informix = "Informix";
    public static final String  JavaDB = "JavaDB";
    public static final String  MySQL4 = "MySQL4";
    public static final String  PointBase = "PointBase";
    public static final String  PostgreSQL = "PostgreSQL";
    public static final String  SQLAnyWhere = "SQLAnyWhere";
    public static final String  SQLServer = "SQLServer";
    public static final String  Sybase = "Sybase";
    public static final String  TimesTen = "TimesTen";
 
    public static final String DEFAULT = Auto;
}

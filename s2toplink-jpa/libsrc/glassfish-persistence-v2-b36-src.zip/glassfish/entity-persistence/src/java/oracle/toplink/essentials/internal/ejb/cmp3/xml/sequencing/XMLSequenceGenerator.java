/*
 * The contents of this file are subject to the terms 
 * of the Common Development and Distribution License 
 * (the "License").  You may not use this file except 
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt or 
 * https://glassfish.dev.java.net/public/CDDLv1.0.html. 
 * See the License for the specific language governing 
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL 
 * HEADER in each file and include the License file at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt.  If applicable, 
 * add the following below this CDDL HEADER, with the 
 * fields enclosed by brackets "[]" replaced with your 
 * own identifying information: Portions Copyright [yyyy] 
 * [name of copyright owner]
 */
// Copyright (c) 1998, 2007, Oracle. All rights reserved.  
package oracle.toplink.essentials.internal.ejb.cmp3.xml.sequencing;

import org.w3c.dom.Node;

import oracle.toplink.essentials.internal.ejb.cmp3.xml.XMLHelper;
import oracle.toplink.essentials.internal.ejb.cmp3.xml.XMLConstants;

import oracle.toplink.essentials.internal.ejb.cmp3.metadata.sequencing.MetadataSequenceGenerator;

/**
 * Object to hold onto an XML sequence generator metadata.
 * 
 * @author Guy Pelletier
 * @since TopLink EJB 3.0 Reference Implementation
 */
public class XMLSequenceGenerator extends MetadataSequenceGenerator {
    private Node m_node;
    private XMLHelper m_helper;
    
    /**
     * INTERNAL:
     */
    public XMLSequenceGenerator(Node node, XMLHelper helper) {
        super(helper.getDocumentName());
        
        m_node = node;
        m_helper = helper;
    }

    /**
     * INTERNAL:
     */
    public int getAllocationSize() {
        return m_helper.getNodeValue(m_node, XMLConstants.ATT_ALLOCATION_SIZE, 50);
    }
    
    /**
     * INTERNAL:
     */
    public int getInitialValue() {
        return m_helper.getNodeValue(m_node, XMLConstants.ATT_INITIAL_VALUE, 0);
    }
    
    /**
     * INTERNAL:
     */
    public String getName() {
        return m_helper.getNodeValue(m_node, XMLConstants.ATT_NAME);
    }
    
    /**
     * INTERNAL:
     */
    public String getSequenceName() {
        return m_helper.getNodeValue(m_node, XMLConstants.ATT_SEQUENCE_NAME, getName());
    }
    
    /**
     * INTERNAL:
     */
    public boolean loadedFromAnnotations() {
       return false; 
    }
    
    /**
     * INTERNAL:
     */
    public boolean loadedFromXML() {
       return true; 
    }
}

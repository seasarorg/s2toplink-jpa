/*
 * The contents of this file are subject to the terms 
 * of the Common Development and Distribution License 
 * (the "License").  You may not use this file except 
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt or 
 * https://glassfish.dev.java.net/public/CDDLv1.0.html. 
 * See the License for the specific language governing 
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL 
 * HEADER in each file and include the License file at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt.  If applicable, 
 * add the following below this CDDL HEADER, with the 
 * fields enclosed by brackets "[]" replaced with your 
 * own identifying information: Portions Copyright [yyyy] 
 * [name of copyright owner]
 */
// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.essentials.exceptions.i18n;

import java.util.ListResourceBundle;

public class PersistenceUnitLoadingExceptionResource extends ListResourceBundle {
 
        static final Object[][] contents = {
                                           { "30001", "An exception was thrown while trying to load a persistence unit for directory: {0}"},
                                           { "30002", "An exception was thrown while trying to load a persistence unit for jar file: {0}"},
                                           { "30003", "An exception was thrown while processing persistence unit at URL: {0}"},
                                           { "30004", "An exception was thrown while processing persistence.xml from URL: {0}"},
                                           { "30005", "An exception was thrown while searching for persistence archives with ClassLoader: {0}"},
                                           { "30006", "An exception was thrown while searching for entities at URL: {0}"},
                                           { "30007", "An exception was thrown while loading class: {0} to check whether it implements @Entity, @Embeddable, or @MappedSuperclass."},
                                           { "30008", "File path returned was empty or null"},                                                                  
                                           { "30009", "An exception was thrown while trying to load persistence unit at url: {0}"},
                                           { "30010", "An exception was thrown while loading ORM XML file: {0}"},
                                           { "30011", "TopLink could not get classes from the URL: {0}.  TopLink attempted to read this URL as a jarFile and as a Directory and was unable to process it."}
    };

    /**
      * Return the lookup table.
      */
    protected Object[][] getContents() {
        return contents;
    }
}

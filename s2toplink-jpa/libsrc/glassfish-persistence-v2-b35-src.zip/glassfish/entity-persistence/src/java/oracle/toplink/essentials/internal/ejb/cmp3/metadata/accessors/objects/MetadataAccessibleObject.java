/*
 * The contents of this file are subject to the terms 
 * of the Common Development and Distribution License 
 * (the "License").  You may not use this file except 
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt or 
 * https://glassfish.dev.java.net/public/CDDLv1.0.html. 
 * See the License for the specific language governing 
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL 
 * HEADER in each file and include the License file at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt.  If applicable, 
 * add the following below this CDDL HEADER, with the 
 * fields enclosed by brackets "[]" replaced with your 
 * own identifying information: Portions Copyright [yyyy] 
 * [name of copyright owner]
 */
// Copyright (c) 1998, 2007, Oracle. All rights reserved.  
package oracle.toplink.essentials.internal.ejb.cmp3.metadata.accessors.objects;

import java.lang.reflect.Type;
import java.lang.reflect.AnnotatedElement;

import oracle.toplink.essentials.internal.ejb.cmp3.metadata.MetadataHelper;

/**
 * Parent object that is used to hold onto a valid EJB 3.0 decorated method
 * or field.
 * 
 * @author Guy Pelletier
 * @since TopLink 10.1.3/EJB 3.0 Preview
 */
public abstract class MetadataAccessibleObject  {
    private String m_name;
    private Class m_rawClass;
    private Type m_relationType;
    private String m_attributeName;
    private Class m_referenceClass;
    private AnnotatedElement m_annotatedElement;
    
    /**
     * INTERNAL:
     */
    public MetadataAccessibleObject(AnnotatedElement annotatedElement) {
        m_annotatedElement = annotatedElement;   
    }
    
    /**
     * INTERNAL:
     * Return the actual field or method.
     */
    public AnnotatedElement getAnnotatedElement() {
        return m_annotatedElement;
    }
    
    /**
     * INTERNAL:
     * Set the relation type of this accessible object.
     */
    public String getAttributeName() {
        return m_attributeName;
    }
    
    /**
     * INTERNAL:
     * This should only be called for accessor's of type Map. It will return
     * the Map key type if generics are used, null otherwise.
     */
    public Class getMapKeyClass() {
        if (MetadataHelper.isGenericCollectionType(m_relationType)) {
            // By default, the reference class is equal to the relation
            // class. But if the relation class is a generic we need to 
            // extract and set the actual reference class from the generic. 
            return MetadataHelper.getMapKeyTypeFromGeneric(m_relationType);
        } else {
            return null;
        }
    }
    
    /**
     * INTERNAL:
     * Set the relation type of this accessible object.
     */
    public String getName() {
        return m_name;
    }
    
    /**
     * INTERNAL:
     * Return the raw class for this accessible object. E.g. For an accessible 
     * object with a type of java.util.Collection<Employee>, this method will 
     * return java.util.Collection.
     */
    public Class getRawClass() {
        if (m_rawClass == null) {
            if (MetadataHelper.isGenericCollectionType(m_relationType)) {
                // By default, the raw class is equal to the relation
                // class. But if the relation class is a generic we need to 
                // extract and set the actual raw class from the generic. 
                m_rawClass = MetadataHelper.getRawClassFromGeneric(m_relationType);
            } else {
                m_rawClass = (Class) m_relationType;
            }
        }
        
        return m_rawClass;    
    }
    
    /**
     * INTERNAL:
     * Return the reference class for this accessible object.
     * Here is what you will get back from this method given the following
     * scenarios:
     * 1 - public Employee getEmployee() => Employee.class
     * 2 - public Collection<String> getTasks() => String.class
     * 3 - public Map<String, Integer> getTasks() => Integer.class
     * 4 - public Collection getTasks() => null
     * 5 - public Map getTasks() => null
     */
    public Class getReferenceClass() {
        if (m_referenceClass == null) {
            if (MetadataHelper.isGenericCollectionType(m_relationType)) {
                // By default, the reference class is equal to the relation
                // class. But if the relation class is a generic we need to 
                // extract and set the actual reference class from the generic. 
                m_referenceClass = MetadataHelper.getReturnTypeFromGeneric(m_relationType);
            } else if (MetadataHelper.isCollectionClass((Class) m_relationType)) {
                // Caller must handle the null if they so care to.
                return null;
            } else if (MetadataHelper.isMapClass((Class) m_relationType)) {
                // Caller must handle the null if they so care to.
                return null;
            } else {
                // Assumes it is a single class, that is, not a map or 
                // collection type. Unsupported collection classes should be 
                // validated long before any calls to this method are made. 
                m_referenceClass = (Class) m_relationType;
            }
        }
        
        return m_referenceClass;
    }
    
    /**
     * INTERNAL:
     * Return the relation type of this accessible object.
     */
    public Type getRelationType() {
        return m_relationType;
    }
    
    /**
     * INTERNAL:
     * Set the annotated element for this accessible object.
     * Once the class loader changes, we need to be able to update our
     * classes.
     */
    public void setAnnotatedElement(AnnotatedElement annotatedElement) {
        m_annotatedElement = annotatedElement;
    }
    
    /**
     * INTERNAL:
     * Set the relation type of this accessible object.
     */
    protected void setAttributeName(String attributeName) {
        m_attributeName = attributeName;
    }
    
    /**
     * INTERNAL:
     * Set the relation type of this accessible object.
     */
    protected void setName(String name) {
        m_name = name;
    }
    
    /**
     * INTERNAL:
     * Set the relation type of this accessible object.
     */
    protected void setRelationType(Type relationType) {
        m_relationType = relationType;
    }
}

/*
 * The contents of this file are subject to the terms 
 * of the Common Development and Distribution License 
 * (the "License").  You may not use this file except 
 * in compliance with the License.
 * 
 * You can obtain a copy of the license at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt or 
 * https://glassfish.dev.java.net/public/CDDLv1.0.html. 
 * See the License for the specific language governing 
 * permissions and limitations under the License.
 * 
 * When distributing Covered Code, include this CDDL 
 * HEADER in each file and include the License file at 
 * glassfish/bootstrap/legal/CDDLv1.0.txt.  If applicable, 
 * add the following below this CDDL HEADER, with the 
 * fields enclosed by brackets "[]" replaced with your 
 * own identifying information: Portions Copyright [yyyy] 
 * [name of copyright owner]
 */
// Copyright (c) 1998, 2006, Oracle. All rights reserved.  
package oracle.toplink.essentials.internal.ejb.cmp3.xml.queries;

import java.util.List;
import java.util.ArrayList;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import oracle.toplink.essentials.internal.ejb.cmp3.xml.XMLHelper;
import oracle.toplink.essentials.internal.ejb.cmp3.xml.XMLConstants;

import oracle.toplink.essentials.internal.ejb.cmp3.metadata.queries.MetadataQueryHint;
import oracle.toplink.essentials.internal.ejb.cmp3.metadata.queries.MetadataNamedNativeQuery;

/**
 * Object to hold onto an XML named native query metadata.
 * 
 * @author Guy Pelletier
 * @since TopLink EJB 3.0 Reference Implementation
 */
public class XMLNamedNativeQuery extends MetadataNamedNativeQuery {
    protected Node m_node;
    protected XMLHelper m_helper;
    
    /**
     * INTERNAL:
     */
    public XMLNamedNativeQuery(Node node, XMLHelper helper) {
        m_node = node;
        m_helper = helper;
    }
    
    /**
     * INTERNAL:
     */
    public String getEJBQLString() {
        return m_helper.getNodeTextValue(m_node, XMLConstants.QUERY);
    }
    
    /**
     * INTERNAL:
     */
    public List<MetadataQueryHint> getHints() {
        if (m_hints == null) {
            m_hints = new ArrayList<MetadataQueryHint>();
            
            NodeList hints = m_helper.getNodes(m_node, XMLConstants.QUERY_HINT);
        
            if (hints != null) {
                for (int i = 0; i < hints.getLength(); i++) {
                    m_hints.add(new XMLQueryHint(hints.item(i), m_helper));
                }
            }
        }
        
        return m_hints;
    }
    
    /**
     * INTERNAL:
     */
    public String getName() {
        return m_helper.getNodeValue(m_node, XMLConstants.ATT_NAME);
    }
    
    /**
     * INTERNAL:
     */
    public Class getResultClass() {
        return m_helper.getNodeValue(m_node, XMLConstants.ATT_RESULT_CLASS, void.class);
    }
    
    /**
     * INTERNAL:
     */
    public String getResultSetMapping() {
        return m_helper.getNodeValue(m_node, XMLConstants.ATT_RESULT_SET_MAPPING, "");
    }
    
    /**
     * INTERNAL:
     */
    public boolean loadedFromAnnotations() {
        return false;
    }
    
    /**
     * INTERNAL:
     */
    public boolean loadedFromXML() {
        return true;
    }
}
